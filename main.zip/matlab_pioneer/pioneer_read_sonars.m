function sonars = pioneer_read_sonars()

global pioneer_sonars;

sonars = pioneer_sonars;

end
