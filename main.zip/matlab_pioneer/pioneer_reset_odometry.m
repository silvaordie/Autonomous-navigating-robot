function pioneer_reset_odometry(sp)

disp('THIS FUNCTION DOES NOT WORK AT ALL');
pioneer_sendmsg(sp, [7]);

end
