function R=rotZ(alfa)

    R=[cos(alfa) -sin(alfa) ; ...
        sin(alfa) cos(alfa) ];

end